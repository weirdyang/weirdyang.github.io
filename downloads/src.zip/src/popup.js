document.addEventListener('DOMContentLoaded', function() {
  const exportButton = document.getElementById('exportButton');
  const importButton = document.getElementById('importButton');
  const fileInput = document.getElementById('fileInput');
  const importOptions = document.getElementById('importOptions');
  const currentWindowButton = document.getElementById('currentWindowButton');
  const newWindowButton = document.getElementById('newWindowButton');
  let importedTabs = [];

  exportButton.addEventListener('click', function() {
    // Get all tabs in the current window
    chrome.tabs.query({currentWindow: true}, function(tabs) {
      // Create HTML content
      const tabData = tabs.map(tab => ({
        title: tab.title || 'Untitled Tab',
        url: tab.url,
        favIconUrl: tab.favIconUrl || '',
        pinned: tab.pinned
      }));

      // Generate the HTML file content
      const html = generateHtmlFile(tabData);

      // Create and trigger download
      const blob = new Blob([html], {type: 'text/html'});
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = 'tabs_export_' + getDateString() + '.html';
      a.click();

      // Clean up
      setTimeout(() => {
        URL.revoObjectURL(url);
      }, 100);
    });
  });

  // Handle import button click
  importButton.addEventListener('click', function() {
    fileInput.click();
  });

  // Handle file selection
  fileInput.addEventListener('change', function(e) {
    if (e.target.files.length === 0) return;

    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
      try {
        // Parse the imported HTML file to extract tab data
        const parser = new DOMParser();
        const doc = parser.parseFromString(e.target.result, 'text/html');

        // Try to extract the JSON data from the script
        const scriptContent = doc.querySelectorAll('script')[0].textContent;
        const tabDataMatch = scriptContent.match(/const tabData = (.*?);/);

        if (tabDataMatch && tabDataMatch[1]) {
          importedTabs = JSON.parse(tabDataMatch[1]);

          // Show import options
          // importOptions.style.display = 'block';
          openImportedTabs(false);
        } else {
          alert('Could not parse tab data from the imported file.');
        }
      } catch (error) {
        alert('Error processing the imported file: ' + error.message);
      }
    };

    reader.readAsText(file);
  });

  // Handle opening tabs in current window
  currentWindowButton.addEventListener('click', function() {
    openImportedTabs(false);
  });

  // Handle opening tabs in new window
  // newWindowButton.addEventListener('click', function() {
  //   openImportedTabs(true);
  // });

  // Function to open imported tabs
  function openImportedTabs() {
    if (importedTabs.length === 0) {
      alert('No tabs to import');
      return;
    }
    // Open all tabs in the current window
    for (let i = 0; i < importedTabs.length; i++) {
      chrome.tabs.create({
        url: importedTabs[i].url,
        pinned: importedTabs[i].pinned
      });
    }

    // Reset UI after import
    // importOptions.style.display = 'none';
    fileInput.value = '';
    importedTabs = [];
  }

  function generateHtmlFile(tabData) {
    // The current date and time for documentation
    const exportDate = new Date().toLocaleString();
    const tabCount = tabData.length;

    // Create JSON data for the tabs that will be embedded in the HTML
    const tabsJson = JSON.stringify(tabData.map(tab => ({
      title: tab.title,
      url: tab.url,
      pinned: tab.pinned
    })));

    // Create a list of tabs as HTML
    let tabListHtml = '<ul id="tab-list">\n';

    tabData.forEach((tab, index) => {
      // Create a favicon element if available
      const favicon = tab.favIconUrl ?
        `<img src="${escapeHtml(tab.favIconUrl)}" alt="favicon" class="favicon" onerror="this.style.display='none';">` :
        '<span class="no-favicon"></span>';

      const pinnedBadge = tab.pinned ? '<span class="pinned-badge">📌</span>' : '';

      tabListHtml += `  <li data-index="${index}">
        ${favicon}
        <a href="${escapeHtml(tab.url)}" class="tab-link" target="_blank" title="${escapeHtml(tab.url)}">
          ${escapeHtml(tab.title)}
        </a>
        ${pinnedBadge}
      </li>\n`;
    });

    tabListHtml += '</ul>';
    const windowId = (Math.random() + 1).toString(36).substring(7);
    // Create the HTML document
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Exported Tabs - ${tabCount} Tabs - ${exportDate}</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      max-width: 1000px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f5f5f5;
    }
    header {
      background-color: #4285f4;
      color: white;
      padding: 20px;
      border-radius: 5px 5px 0 0;
      margin-bottom: 0;
    }
    .container {
      background-color: white;
      border-radius: 5px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      overflow: hidden;
    }
    h1 {
      margin-top: 0;
    }
    .export-info {
      color: #eee;
      font-size: 14px;
    }
    .tab-container {
      padding: 20px;
    }
    #tab-list {
      list-style-type: none;
      padding: 0;
    }
    #tab-list li {
      padding: 10px;
      border-bottom: 1px solid #eee;
      display: flex;
      align-items: center;
    }
    #tab-list li:last-child {
      border-bottom: none;
    }
    #tab-list a {
      color: #1a73e8;
      text-decoration: none;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
    }
    #tab-list a:hover {
      text-decoration: underline;
    }
    .favicon {
      width: 16px;
      height: 16px;
      margin-right: 10px;
    }
    .no-favicon {
      width: 16px;
      height: 16px;
      background-color: #ddd;
      border-radius: 50%;
      display: inline-block;
      margin-right: 10px;
    }
    .pinned-badge {
      color: #888;
      margin-left: 8px;
      font-size: 14px;
    }
    .instructions {
      background-color: #f8f9fa;
      padding: 15px;
      border-radius: 4px;
      margin: 20px 0;
      font-size: 14px;
      color: #555;
    }
    .status {
      display: none;
      margin-top: 10px;
      padding: 8px;
      background-color: #e8f0fe;
      border-left: 4px solid #4285f4;
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>Exported Tabs (${tabCount})</h1>
      <div class="export-info">Exported on ${exportDate}</div>
    </header>

    <div class="tab-container">
      <div class="instructions">
        <p><strong>Instructions:</strong> Click on an individual link to open that tab, or use the "Import Tabs" function in the extension to open all tabs at once.</p>
      </div>

      <h2>Your Tabs:</h2>
      ${tabListHtml}
    </div>
  </div>

  <script>
    // Store the tab data
    const tabData = ${tabsJson};

    // Prevent default link behavior to handle opening ourselves
    document.querySelectorAll('.tab-link').forEach(link => {
      link.addEventListener('click', function(e) {
        // Allow middle-click or ctrl+click to work normally
        if (e.ctrlKey || e.metaKey || e.button === 1) {
          return true;
        }

        e.preventDefault();
        window.open(this.href, '_blank');
      });
    });
  </script>
</body>
</html>`;
  }

  // Helper function to escape HTML special characters
  function escapeHtml(unsafe) {
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function getDateString() {
    const date = new Date();
    return date.getFullYear() + '-' +
           padZero(date.getMonth() + 1) + '-' +
           padZero(date.getDate()) + '_' +
           padZero(date.getHours()) + '-' +
           padZero(date.getMinutes());
  }

  function padZero(num) {
    return num.toString().padStart(2, '0');
  }
});